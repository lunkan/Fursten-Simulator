-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Värd: localhost
-- Skapad: 26 februari 2013 kl 11:54
-- Serverversion: 5.5.8
-- PHP-version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databas: `fursten_simulator`
--

-- --------------------------------------------------------

--
-- Struktur för tabell `nodes`
--

CREATE TABLE IF NOT EXISTS `nodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_key` int(11) NOT NULL,
  `node_tree` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Data i tabell `nodes`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `resources`
--

CREATE TABLE IF NOT EXISTS `resources` (
  `id` int(11) NOT NULL,
  `resource_object` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data i tabell `resources`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `id` int(11) NOT NULL,
  `session_object` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data i tabell `sessions`
--

